import { View, Text } from "react-native";
import React from "react";
import { Stack, router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";

const AuthLayout = () => {
  return (
    <Stack>
      <Stack.Screen
        name="WelcomeScreen"
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="PhoneLoginScreen"
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerLeft: () => (
            <Ionicons
              onPress={() => router.back()}
              name="chevron-back"
              size={24}
              color="black"
            />
          ),
          headerTitle: "",
        }}
      />
      <Stack.Screen
        name="OtpScreen"
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerLeft: () => (
            <Ionicons
              onPress={() => router.back()}
              name="chevron-back"
              size={24}
              color="black"
            />
          ),
          headerTitle: "",
        }}
      />
      <Stack.Screen
        name="EnterPersonalDetailScreen"
        options={{
          headerShown: false,
          headerShadowVisible: false,
          headerTitle: "",
        }}
      />
    </Stack>
  );
};

export default AuthLayout;
