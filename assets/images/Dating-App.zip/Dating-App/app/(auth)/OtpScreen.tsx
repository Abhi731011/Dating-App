import { View, Text, Button, ButtonText } from "tamagui";
import React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { TextInput } from "react-native";
import { Colors } from "@/constants/Colors";
import Feather from "@expo/vector-icons/Feather";
import { router, useNavigation } from "expo-router";

const OtpScreen = () => {
  return (
    <SafeAreaView style={{ backgroundColor: "white", flex: 1 }}>
      <View w={"90%"} alignSelf="center" flex={1}>
        <Text
          width={200}
          textAlign="center"
          color={"grey"}
          alignSelf="center"
          fontSize={14}
          lineHeight={30}
          fontFamily={"Mulish"}
        >
          Please enter the 4 Digit OTP sent to +62812-0101-0101
        </Text>

        <View flexDirection="row" justifyContent="space-between" marginTop={30}>
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: "grey",
              fontSize: 25,
              paddingHorizontal: 10,
              textAlign: "center",
            }}
          />
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: "grey",
              fontSize: 25,
              paddingHorizontal: 10,
              textAlign: "center",
            }}
          />
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: "grey",
              fontSize: 25,
              paddingHorizontal: 10,
              textAlign: "center",
            }}
          />
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: "grey",
              fontSize: 25,
              paddingHorizontal: 10,
              textAlign: "center",
            }}
          />
        </View>
        <Text
          width={200}
          textAlign="center"
          color={"grey"}
          alignSelf="center"
          fontSize={14}
          marginTop={"10%"}
          lineHeight={30}
          fontFamily={"Mulish"}
        >
          Don't tell anyone the code
        </Text>
        <Text
          width={200}
          textAlign="center"
          color={"grey"}
          alignSelf="center"
          fontSize={14}
          lineHeight={30}
          fontFamily={"Mulish"}
        >
          Expiring in 04:59
        </Text>

        <Button
          pressStyle={{
            backgroundColor: "transparent",
            borderWidth: 0,
          }}
          backgroundColor="transparent" // No background color
          flexDirection="row"
          alignItems="center"
          justifyContent="center"
          height={50}
          marginTop={"5%"}
        >
          <ButtonText
            pressStyle={{
              color: "#EF4765",
            }}
            color={"lightpink"}
            fontWeight={600}
            textAlign="center"
            fontSize={12}
          >
            RESEND OTP
          </ButtonText>
        </Button>

        <Button
          pressStyle={{
            backgroundColor: Colors.primary,
            opacity: 0.7,
          }}
          backgroundColor={Colors.primary}
          flexDirection="row"
          alignItems="center"
          justifyContent="center"
          height={60}
          borderRadius={10}
          marginTop={"10%"}
          onPress={() =>{
            router.navigate("/(auth)/EnterPersonalDetailScreen")
          }}
        >
          <ButtonText
            color={"white"}
            fontWeight={"bold"}
            textAlign="center"
            fontFamily={"poppins"}
          >
            Accept
          </ButtonText>
        </Button>
      </View>
      <Text
        textAlign="center"
        color={"grey"}
        alignSelf="center"
        fontSize={12}
        paddingBottom={20}
      >
        Term Of Use Privacy & Policy
      </Text>
    </SafeAreaView>
  );
};

export default OtpScreen;
