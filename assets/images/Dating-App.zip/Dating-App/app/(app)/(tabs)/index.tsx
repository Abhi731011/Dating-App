import { View, Text, Button, ButtonText, Image } from "tamagui";
import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { ImageBackground, ScrollView, TextInput } from "react-native";
import { Colors } from "@/constants/Colors";
import { router, useNavigation } from "expo-router";
import Feather from "@expo/vector-icons/Feather";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { FontAwesome5 } from "@expo/vector-icons";
import AntDesign from "@expo/vector-icons/AntDesign";
import { TouchableOpacity } from "react-native";

const Homescreen = () => {
  return (
    <SafeAreaView style={{ backgroundColor: "white", flex: 1 }}>
      <View w={"90%"} alignSelf="center" flex={1} marginTop={10}>
      
        <View
          width={320}
          height={528}
          justifyContent="center"
          alignItems="center"
          alignSelf="center"
          marginTop={"20%"}
        >
          <TouchableOpacity
            onPress={() => {
              router.navigate("/(app)/ProfileScreen");
            }}
          >
            <Image source={require("@/assets/images/HomeImage.png")} />
          </TouchableOpacity>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: "white",
              borderRadius: 15,
              padding: 15,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.2,
              shadowRadius: 1.41,
              elevation: 2,
            }}
          >
            <View flex={1}>
              <Text fontSize={16} fontWeight={"bold"} color={"#333"}>
                Jennifer, 22
              </Text>
              <Text fontSize={14} color={"#888"} marginTop={4}>
                Model Fashion
              </Text>
            </View>

            <View flexDirection="row" alignItems="center">
              <FontAwesome5 name="map-marker-alt" size={14} color="#FF5C5C" />
              <Text fontSize={14} color={"#555"} marginLeft={5}>
                5 Km
              </Text>
            </View>
          </View>
        </View>
        {/* Buttons Section */}
        <View
          flexDirection="row"
          justifyContent="space-around"
          marginTop={"10%"}
          width={"100%"}
         >
          {/* Cancel Button */}
          <TouchableOpacity
            style={{
              backgroundColor: "white",
              width: 60,
              height: 60,
              borderRadius: 30,
              justifyContent: "center",
              alignItems: "center",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.25,
              shadowRadius: 3.84,
              elevation: 5,
            }}
          >
            <AntDesign name="close" size={28} color="grey" />
          </TouchableOpacity>

          {/* Favorite Button */}
          <TouchableOpacity
            style={{
              backgroundColor: "#FF5C5C",
              width: 60,
              height: 60,
              borderRadius: 30,
              justifyContent: "center",
              alignItems: "center",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.25,
              shadowRadius: 3.84,
              elevation: 5,
            }}
          >
            <AntDesign name="hearto" size={28} color="white" />
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Homescreen;
