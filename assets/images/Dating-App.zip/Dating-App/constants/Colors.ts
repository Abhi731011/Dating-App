export const Colors = {
  primary:"#EF4765",
  background:"#FFFFFF",
  Xcrino: "#5D5D5D",
  lightpink:'#FF9BAD'
}